export { default as EventGallery } from "./event-gallery"
