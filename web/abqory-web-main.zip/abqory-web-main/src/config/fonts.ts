import { Inter } from "next/font/google"

export const inter = Inter({
  variable: "--inter-font",
  weight: ["400", "500", "600", "700"],
  style: "normal",
  subsets: ["latin"],
})
